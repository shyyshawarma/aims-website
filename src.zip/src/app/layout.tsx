import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AIMS-DTU",
  description: "Official Website for the AIMS Society at DTU.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}