"use client";

import { motion } from "framer-motion";
import { Code, University, ArrowRight, Sparkles } from "lucide-react";

export default function HomePage() {
  // Animation variants for Framer Motion
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
        duration: 0.8,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring" as const,
        stiffness: 100,
        damping: 15,
      },
    },
  };

  const glowVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 1.2,
        ease: "easeOut" as const,
      },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-radial relative overflow-hidden">
      {/* Animated background glow */}
      <div className="absolute inset-0 bg-gradient-radial from-blue-900/20 via-black to-black"></div>
      
      {/* Blue spray effects */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Large blue spray particles */}
        <motion.div
          className="absolute top-10 left-10 w-4 h-4 bg-blue-400 rounded-full opacity-40 blur-sm"
          animate={{
            x: [0, 50, 0],
            y: [0, -30, 0],
            opacity: [0.4, 0.8, 0.4],
            scale: [1, 1.5, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute top-20 right-20 w-3 h-3 bg-blue-500 rounded-full opacity-30 blur-sm"
          animate={{
            x: [0, -40, 0],
            y: [0, -20, 0],
            opacity: [0.3, 0.7, 0.3],
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
        />
        <motion.div
          className="absolute bottom-20 left-1/4 w-2 h-2 bg-blue-300 rounded-full opacity-50 blur-sm"
          animate={{
            x: [0, 30, 0],
            y: [0, -40, 0],
            opacity: [0.5, 0.9, 0.5],
            scale: [1, 1.4, 1],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2,
          }}
        />
        
        {/* Small blue spray particles */}
        <motion.div
          className="absolute top-40 left-1/3 w-1 h-1 bg-blue-400 rounded-full opacity-60"
          animate={{
            y: [0, -25, 0],
            opacity: [0.6, 1, 0.6],
            x: [0, 15, 0],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute top-60 right-1/3 w-1 h-1 bg-blue-500 rounded-full opacity-40"
          animate={{
            y: [0, -20, 0],
            opacity: [0.4, 0.8, 0.4],
            x: [0, -10, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5,
          }}
        />
        <motion.div
          className="absolute bottom-40 left-1/2 w-1 h-1 bg-blue-300 rounded-full opacity-50"
          animate={{
            y: [0, -35, 0],
            opacity: [0.5, 0.9, 0.5],
            x: [0, 20, 0],
          }}
          transition={{
            duration: 4.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1.5,
          }}
        />
        
        {/* Blue spray mist effects */}
        <motion.div
          className="absolute top-0 left-0 w-full h-full"
          style={{
            background: 'radial-gradient(circle at 20% 30%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)',
          }}
          animate={{
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute top-0 right-0 w-full h-full"
          style={{
            background: 'radial-gradient(circle at 80% 40%, rgba(37, 99, 235, 0.08) 0%, transparent 60%)',
          }}
          animate={{
            opacity: [0.08, 0.25, 0.08],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2,
          }}
        />
      </div>
      
      {/* Floating particles effect */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-20 left-20 w-2 h-2 bg-yellow-400 rounded-full opacity-60"
          animate={{
            y: [0, -20, 0],
            opacity: [0.6, 1, 0.6],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute top-40 right-32 w-1 h-1 bg-blue-400 rounded-full opacity-40"
          animate={{
            y: [0, -15, 0],
            opacity: [0.4, 0.8, 0.4],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
        />
      </div>

      {/* Header */}
      <header className="relative z-10 px-8 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <motion.div 
            className="flex items-center gap-3"
            variants={itemVariants}
            initial="hidden"
            animate="visible"
          >
            <div className="relative">
              {/* AIMS-DTU Logo */}
              <img 
                src="/aims-logo.png" 
                alt="AIMS-DTU Logo" 
                className="h-8 w-8 object-contain"
              />
              {/* <motion.div
                className="absolute inset-0 bg-blue-400 rounded-lg opacity-20 blur-sm"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.2, 0.4, 0.2],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }} */}
              {/* /> */}
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              AIMS-DTU
            </h1>
          </motion.div>
          
          <motion.nav 
            className="hidden md:flex items-center gap-8"
            variants={itemVariants}
            initial="hidden"
            animate="visible"
          >
            <a href="#" className="text-gray-300 hover:text-white transition-colors duration-300 font-medium">
              About
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition-colors duration-300 font-medium">
              Achievements
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition-colors duration-300 font-medium">
              Team
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition-colors duration-300 font-medium">
              Projects
            </a>
          </motion.nav>

          <motion.button 
            className="bg-black text-white px-6 py-3 rounded-lg font-semibold border border-gray-700 hover:border-yellow-400 transition-all duration-300 hover:shadow-lg hover:shadow-yellow-400/20"
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get Involved
          </motion.button>
        </div>
      </header>

      {/* Main Hero Section */}
      <main className="relative z-10 flex items-center justify-center min-h-[80vh] px-8">
        <motion.div
          className="w-full max-w-6xl text-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Glowing icon
          <motion.div 
            className="flex justify-center mb-8"
            variants={glowVariants}
          >
            <div className="relative">
              <University className="h-20 w-20 text-blue-400 relative z-10" />
              <motion.div
                className="absolute inset-0 bg-blue-400 rounded-full opacity-30 blur-xl"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            </div> */}
          {/* </motion.div> */}

          {/* Main headline */}
          <motion.h1
            className="text-7xl md:text-9xl font-black tracking-tight mb-5 bg-gradient-to-r from-grey via-yellow-400 to-white bg-clip-text text-transparent drop-shadow-2xl"
            variants={itemVariants}
          >
            <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.5)]">AIMS</span>
            <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.5)]">-</span>
            <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.5)]">DTU</span>
          </motion.h1>

          {/* Subtitle with neon blue underline */}
          <motion.div
            className="relative inline-block mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
              Pioneering the Future of AI & ML
            </h2>
            <div className="h-1 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full shadow-lg shadow-blue-400/50"></div>
          </motion.div>

          {/* Description */}
          <motion.p
            className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto mb-12 leading-relaxed"
            variants={itemVariants}
          >
            Join our community of innovators and builders at Delhi Technological University. 
            We're pushing the boundaries of artificial intelligence and machine learning.
          </motion.p>
          
          {/* CTA Buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
            variants={itemVariants}
          >
            <motion.button 
              className="group bg-black text-white px-8 py-4 rounded-lg font-bold text-lg border-2 border-gray-700 hover:border-yellow-400 transition-all duration-300 hover:shadow-xl hover:shadow-yellow-400/20 flex items-center gap-3"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              Explore Projects
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
            </motion.button>
            
            <motion.button 
              className="group bg-transparent text-white px-8 py-4 rounded-lg font-bold text-lg border-2 border-gray-600 hover:border-blue-400 transition-all duration-300 hover:shadow-xl hover:shadow-blue-400/20 flex items-center gap-3"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              <Sparkles className="h-5 w-5 text-blue-400" />
              Join Us
            </motion.button>
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
}